//***************************************************
// Account Global Defaults
//***************************************************
 
var AccountType = 0;
var AccountDataFolder = "000000000000";
var ConfigOptions = 1;
 
//***************************************************
// Page Parameters Global Defaults
//***************************************************
 
var PageID = 0;
var CookiePrefix = "SS_Globals5";
var PageLayout = 2;
var DialStart = 0;
var PageBackGroundColor = "#151f45";
var PageForeGroundColor = "#FFFFFF";
var ClockLCDColor = 0;
var SystemClockPGNID = 7;
var UpdateInterval = 3000;
var DialTimeout = 4;
var xmlDescription = "Stainless Engine Dials 4X2";
 
//***************************************************
// Dial Parameters Global Defaults
//***************************************************
 
var DialType = new Array(16,16,16,16,16,16,16,16,16,16,16,16,15,15,15,15);
var DialPGNInstance = new Array(0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1);
var DialPGNNumber = new Array("127501","127501","127501","127501","127501","127501","127501","127501","127501","127501","127501","127501","127501","127501","127501","127501");
var DialPGNParameter = new Array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15);
var DialUnits = new Array(0,24,4,8,26,28,0,27,16,4,4,0,10,16,16,16);
var DialMin = new Array(0,0,0,0,0,0,0,0,0,0,0,0,26,-60,-50,0);
var DialMax = new Array(250,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255);
var DialAlarm = new Array(128,128,128,128,128,128,128,128,128,128,128,128,128,128,128,128);
var DialAlarmState = new Array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
var DialText = new Array("Bilge","Sonar","P FAN","S FAN","P WIPER","S WIPER","P NAVL","S NAVL","P SPOT","S SPOT","RUNLGHT","ANCHORL","NA","NA","NA","NA");
var DialFrameType = new Array(5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5);
var DialBackground = new Array(16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16);
var DialLCDColor = new Array(17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17);
var DialPointerColor = new Array(3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3);
var DialPonterType = new Array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0); 